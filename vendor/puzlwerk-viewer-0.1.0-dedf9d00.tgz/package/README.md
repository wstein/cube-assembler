# Viewer pilot

This private AGPL-3.0-or-later package presents caller-owned projections with
Three.js 0.187.0. It does not parse moves or maintain canonical puzzle state.
The demo adapts the existing ReScript shell and orientation functions for one
2×2 turn. Applications have not been migrated.

From the repository root, run `npm ci`, `npm run build`, then
`npm run dev --workspace @puzlwerk/viewer`. Open the printed localhost URL.
The existing root `npm run check` includes the viewer unit suite; `npm run test:package` includes its typecheck and build. The optional browser smoke
uses an installed Playwright module and Chromium: with the demo server running,
set `PLAYWRIGHT_MODULE` to the absolute path of Playwright's `index.mjs` and run
`node packages/viewer/test/browser-smoke.mjs`. It tests desktop and mobile
viewport sizes, not physical devices.

The API and validation rules follow spec 009. Scene coordinates are right-handed;
sticker local +Z points outward and +Y points up. The numerical tolerance for
unit lengths, rotated positions and quaternion equivalence is 1e-6. Inputs are
copied at operation start. IDs and sticker definitions remain stable across a
transition. The application supplies the full signed angle and total duration;
zero completes immediately and smoothstep easing uses that duration once. The demo passes zero duration when the system requests reduced motion; the viewer does not override the supplied duration. The
browser clock uses `performance.now`; a zero duration completes visually
immediately. A successful visual completion does not commit application state. Cancellation restores the source projection, returns `Cancelled`, and does not commit the target. The owner selected the pilot visibility, reduced-motion, easing, and cancellation policies on 2026-11-15.

CanvasImageSource assets remain caller-owned; textures are viewer-owned. Images
use sRGB and Three.js texture defaults (including its default vertical flip),
with alpha enabled for image stickers. Applications own the host and assets.
The viewer disposes its geometry, materials and textures and ignores late asset
results after cancellation. Context loss requires disposal and recreation. The
host size is observed when ResizeObserver is available; `invalidate` requests
one coalesced frame. No continuous frames run while idle. See NOTICE for source
and license provenance. When the document is hidden, rendering and animation time pause; on return the transition resumes without a jump. This does not change Cubistry TimerController behavior; consumer synchronization remains a separate migration concern.


The pilot uses Cubistry's 2×2 presentation values: a maximum body width of
0.99, outer bevel radius 0.03, inner radius 0.018 (60%), three bevel
segments, and rounded sticker corners with radius 0.055 and four curve segments.
Without explicit geometry the adapter keeps caller-supplied piece positions and bounds body width to 0.94–0.99, preserving the pilot's earlier 0.471 sticker offset. Optional piece geometry supplies three cell extents and three pairs of exterior-side flags to the source profile; each extent must exceed the source gap. This changes only body geometry, leaves poses and sticker data untouched, and must remain unchanged across a transition. Cubistry's native 2×2 profile instead uses 1.012 outer layers, 1.002 bodies, and shifted stickers. The demo uses Cubistry's 0.502 offset and 0.87 sticker width. The plastic
uses the Classic palette's #1b2431, roughness 0.45 and clearcoat 0.18;
stickers use roughness 0.65 and clearcoat 0.12. The studio uses Cubistry's
ambient, hemisphere, key, fill, rim and shadow-fill lights, two 1024-pixel
shadow maps and the contact shadow. Renderer output uses sRGB, neutral tone
mapping and a device pixel ratio capped at 2. See NOTICE for pinned sources.

The model gallery is at `packages/viewer/demo/gallery.html` on the demo server.
It shows native 2×2, 3×3 and 7×7 and an unequal [0.7, 1, 1.4] profile at
rest and mid-turn. `presentation` supplies the explicit size and nominal edge;
optional `core` supplies a scene-space center and positive half extent. These
are render-only snapshot data, invariant across a transition. No core is inferred.
The source-versus-adapter captures use Chromium with SwiftShader at DPR 1,
300×300 drawing buffers, camera (4,3,5) scaled by max(1, edge/2), and the
pinned studio. Desktop and mobile viewport captures are local test artifacts,
not physical-device or full HQ acceptance. The model-profile slice did not
include artwork or picture projection; the subsequent artwork slice is described
below. Multiple cubes remain open.


Optional appearance, source-face and picture metadata select the source
stickerless, miter and projected-picture builders. Picture faces use opaque
asset IDs whose returned pixels are already in Cubistry's bottom-left
orientation; legacy per-sticker imageId behavior is unchanged. Source-face
frames and picture indices are immutable construction references, not current
world positions. Optional source-face color is independent of sticker image tint;
omitting it uses the normalized sticker color. `setArtwork` applies a complete decoration replacement
during a turn without changing physical poses; successful updates survive
cancellation. Asset failure and late completion leave the committed scene
unchanged. See spec 009 for validation, ownership and concurrency rules.

The local `artwork-gallery.html` shows 2×2, 3×3, 7×7 and unequal profiles
in tile, plain stickerless, miter, picture-sticker and picture-body modes. It
renders each view with WebGL, copies the finished frame to a display canvas and
releases the context before rendering the next view. This gallery does not
establish full Stage 1 HQ acceptance or migrate any application.

The shared-stage demo is at `packages/viewer/demo/stage.html`. `createCubeStage`
creates one renderer, studio and camera for independently operated child
scenes; `createCubeScene` retains its single-child interface. Stage view policies
and lighting receive or supply render-only data. Applications own layouts,
assets, appearance policy and state. Registered interaction surfaces remain
caller-owned. Disposal removes the canvas and releases its WebGL context.

The demo uses two and three source-framed cubes and a 7×7 source Names geometry
and lighting setup with a synthetic asymmetric Canvas glyph and miter, not calendar print data.
Its browser test uses `PLAYWRIGHT_MODULE` as above and
`node packages/viewer/test/stage-browser-smoke.mjs` with the demo server running.
It checks desktop/mobile viewport sizes, source-derived sample colors, input,
turns, artwork updates, idle rendering, context loss and disposal. Browser
viewports are not physical-device or full HQ acceptance.

## Bridge subpath and CubeAssembler state

`@puzlwerk/viewer/bridge` ships the Core-to-viewer bridge with the compiled Core modules it imports
(`npm run build --workspace @puzlwerk/viewer` copies them to `dist/bridge`; the packed tarball is
self-contained apart from `three` and `@rescript/runtime`). It adds `cubeStateDocuments(size, cube, palette)`,
which turns CubeAssembler's CubeState (six facelet arrays, sizes 2 to 7) into wire-v1 definition, home state,
appearance and `open` options with the standard layer widths; `cubeStateFromWire` reads the facelets back after
turns; `faceStickerIds(size, face)` lists the viewer sticker IDs of one face. A facelet-only state has no piece
identity, so the appearance carries each slot's color. `CubeStage.setStickerHighlight(child, ids)` outlines those
stickers (static view; reapply it after `setProjection`).
`createCubeStage` takes `appearanceControls: 'hidden'` for hosts that supply their own controls (default
`'floating'`); the panel is still created, only not shown.
