export type face = "U" | "R" | "F" | "D" | "L" | "B";
export type grid = Array<string[]>;
export type observation = {
    readonly photoId: string;
    readonly slot: string;
    readonly revision: number;
    readonly sourceGrid: grid;
    readonly sourceHash: string;
    readonly guideProtocol: (undefined | string);
    readonly guideStep: (undefined | number);
    readonly mirrored: (undefined | boolean);
};
export type input = {
    readonly captureId: string;
    readonly revision: number;
    readonly size: number;
    readonly observations: observation[];
};
export type placement = {
    readonly photoId: string;
    readonly observationRevision: number;
    readonly target: face;
    readonly quarterTurns: number;
};
export type legacyTransform = {
    readonly convention: string;
    readonly index: number;
};
export type slotPlacement = {
    readonly slot: string;
    readonly target: face;
    readonly quarterTurns: number;
};
export type slotCandidateInput = {
    readonly candidateId: string;
    readonly captureRevision: number;
    readonly mappingFrame: string;
    readonly canonicalTransform: (undefined | number[]);
    readonly legacyTransform: (undefined | legacyTransform);
    readonly mapping: slotPlacement[];
};
export type candidateInput = {
    readonly candidateId: string;
    readonly captureRevision: number;
    readonly mappingFrame: string;
    readonly canonicalTransform: (undefined | number[]);
    readonly legacyTransform: (undefined | legacyTransform);
    readonly mapping: placement[];
};
export type projection = {
    readonly photoId: string;
    readonly slot: string;
    readonly observationRevision: number;
    readonly target: face;
    readonly quarterTurns: number;
    readonly sourceHash: string;
    readonly grid: grid;
};
export type outcome<a> = {
    ok: true;
    readonly value: a;
} | {
    ok: false;
    readonly error: string;
};
export declare abstract class capture {
    protected opaque: any;
}
export declare abstract class candidate {
    protected opaque: any;
}
export declare const createCapture: (_1: input) => outcome<capture>;
export declare const snapshot: (_1: capture) => input;
export declare const createCandidate: (_1: capture, _2: candidateInput) => outcome<candidate>;
export declare const describeCandidate: (_1: candidate) => candidateInput;
export declare const photoForFace: (_1: capture, _2: (undefined | candidate), _3: face) => (undefined | projection);
export declare const projectMapping: (_1: capture, _2: candidate, _3: number[]) => outcome<projection[]>;
export declare const identityTransform: () => number[];
export declare const createCandidateFromSlots: (_1: capture, _2: slotCandidateInput) => outcome<candidate>;
export declare const replaceObservation: (_1: capture, _2: number, _3: observation) => outcome<capture>;
export declare const invalidateCapture: (_1: capture, _2: number) => outcome<capture>;
export declare const observationHistory: (_1: capture) => observation[];
export declare const synchronizeObservations: (_1: capture, _2: number, _3: observation[]) => outcome<capture>;
export declare const verifySourceHash: (_1: capture, _2: string, _3: string) => boolean;
