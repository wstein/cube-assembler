export * from './PwCapture.gen.js';
