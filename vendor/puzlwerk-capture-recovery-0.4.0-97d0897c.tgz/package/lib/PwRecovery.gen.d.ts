import type { candidateInput as PwCapture_candidateInput } from './PwCapture.gen.ts';
import type { candidate as PwCapture_candidate } from './PwCapture.gen.ts';
import type { capture as PwCapture_capture } from './PwCapture.gen.ts';
import type { face as PwCapture_face } from './PwCapture.gen.ts';
import type { grid as PwCapture_grid } from './PwCapture.gen.ts';
import type { outcome as PwCapture_outcome } from './PwCapture.gen.ts';
import type { placement as PwCapture_placement } from './PwCapture.gen.ts';
import type { projection as PwCapture_projection } from './PwCapture.gen.ts';
export type center = {
    readonly target: PwCapture_face;
    readonly color: string;
};
export type reviewedGrid = {
    readonly photoId: string;
    readonly grid: PwCapture_grid;
};
export type reviewed = {
    readonly captureRevision: number;
    readonly grids: reviewedGrid[];
};
export type request = {
    readonly action: string;
    readonly searchId: string;
    readonly maxEvaluated: number;
    readonly maxCandidates: number;
    readonly centers: center[];
    readonly reviewedGrids: (undefined | reviewed);
};
export type check = {
    readonly status: string;
    readonly checkerId: string;
    readonly sourceRevision: string;
    readonly scope: string;
    readonly issues: string[];
};
export type wireInput = {
    readonly definitionJSON: string;
    readonly stateJSON: string;
    readonly faceTurnsAssumed: boolean;
};
export type assessment = {
    readonly feasibility: check;
    readonly wire: (undefined | wireInput);
};
export type wireReport = {
    readonly structural: boolean;
    readonly reachability: string;
    readonly method: string;
    readonly profile: string;
    readonly scope: string;
};
export type retained = {
    readonly candidate: PwCapture_candidateInput;
    readonly feasibility: check;
    readonly wireReport: (undefined | wireReport);
};
export type summary = {
    readonly searchId: string;
    readonly evaluated: number;
    readonly workVisited: number;
    readonly workLimit: number;
    readonly inconclusive: number;
    readonly coverage: string;
    readonly truncated: boolean;
    readonly candidates: retained[];
};
export type choice = {
    readonly placement: PwCapture_placement;
    readonly grid: PwCapture_grid;
    readonly candidateIds: string[];
};
export declare abstract class session {
    protected opaque: any;
}
export declare abstract class review {
    protected opaque: any;
}
export type confirmation = {
    readonly candidate: PwCapture_candidate;
    readonly projection: PwCapture_projection[];
    readonly feasibility: check;
    readonly wireReport: (undefined | wireReport);
};
export type committed = {
    readonly review: review;
    readonly confirmed: confirmation;
};
export type resumeConflict = {
    readonly decision: (undefined | PwCapture_placement);
    readonly reason: string;
};
export type resumed = {
    readonly session: session;
    readonly review: review;
    readonly carriedDecisions: PwCapture_placement[];
    readonly conflicts: resumeConflict[];
    readonly status: string;
};
export declare const assessWire: (_1: wireInput) => wireReport;
export declare const findMatchingCube: (_1: PwCapture_capture, _2: request, _3: ((_1: PwCapture_candidateInput, _2: PwCapture_projection[]) => assessment)) => PwCapture_outcome<session>;
export declare const describeSession: (_1: session) => summary;
export declare const beginReview: (_1: session) => review;
export declare const revision: (_1: review) => number;
export declare const canBack: (_1: review) => boolean;
export declare const nextTarget: (_1: review) => (undefined | PwCapture_face);
export declare const choices: (_1: review) => choice[];
export declare const select: (_1: review, _2: number, _3: PwCapture_placement) => PwCapture_outcome<review>;
export declare const back: (_1: review, _2: number) => PwCapture_outcome<review>;
export declare const cancel: (_1: review, _2: number) => PwCapture_outcome<review>;
export declare const selectedCandidate: (_1: review) => (undefined | PwCapture_candidateInput);
export declare const useCandidate: (_1: PwCapture_capture, _2: review, _3: number, _4: string, _5: ((_1: PwCapture_candidateInput, _2: PwCapture_projection[]) => assessment)) => PwCapture_outcome<committed>;
export declare const projectCandidate: (_1: session, _2: string) => (undefined | PwCapture_projection[]);
export declare const resumeReview: (_1: PwCapture_capture, _2: review, _3: number, _4: request, _5: ((_1: PwCapture_candidateInput, _2: PwCapture_projection[]) => assessment)) => PwCapture_outcome<resumed>;
export declare const backAndResumeReview: (_1: PwCapture_capture, _2: review, _3: number, _4: request, _5: ((_1: PwCapture_candidateInput, _2: PwCapture_projection[]) => assessment)) => PwCapture_outcome<resumed>;
